data/ directory is bundled automatically for emscripten web builds.

  * video1.rgb is a raw 32x32 RGB asset copied from Downloads on 2026-04-14.
  * screenmap.json is the 32x32 screen map resource for `strip1`.
  * Source for screenmap.json: C:\Users\niteris\dev\ledmapper\public\screenmaps\32x32_quad_serpentine.json
  * ledmapper-32x32-video1-asset.zip is a standalone package containing video1.rgb, screenmap.json, and this readme.
  * File size: 6,051,840 bytes.
  * Frame size at 32x32 RGB888: 3,072 bytes.
  * Total frames: 1,970.
  * Expected playback duration:
    - 65.67s at 30 FPS
    - 32.83s at 60 FPS
  * The sketch defaults to VIDEO_FPS = 30. Change that constant if the export was authored at a different rate.
  * screenmap.json SHA-256: a6851e2a5eaf728b0018f1a32918969b2e90673ed2c18c1a3a5d7327cf5993d7
  * Assumption: the asset is already mapped into physical LED order for the target ledmapper.com model.
